eggs = int(input("How many eggs would you like to order?\t"))

dozens = eggs // 12
singles = eggs % 12

dozensPrice = dozens * 3.25
singlesPrice = singles * 0.45

totalPrice = dozensPrice + singlesPrice

print(f"\nYour order summary:\n{dozens} dozen/s of eggs and {singles} single egg/s")
print(f"Prices: R{dozensPrice} for your {dozens} dozen/s\n\tR{singlesPrice} for your {singles} single egg/s")
print(f"Your order total will be: R{totalPrice}")
print(f"\nThank you for shopping with us!!!")