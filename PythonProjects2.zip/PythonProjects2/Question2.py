inputNumber = 2000
orignalInputNumber = inputNumber
primeNumbers = [2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71,73,79,83,89,97] #Prime Factors from 1-100
savedFactors = []
i = 0 #Index

while(True):
    #print(inputNumber), was used for testing data flow
    if(inputNumber % primeNumbers[i] == 0): # Checking if value is divsible by the selected prime factor in the list
        savedFactors.append(primeNumbers[i]) # Saves the prime factor that was accepted
        inputNumber = inputNumber/primeNumbers[i] # divides the input value

    elif(primeNumbers.count(inputNumber) != 0 or inputNumber == 1): #checking for ending conditions
        if(inputNumber != 1):
            savedFactors.append(inputNumber) #saves last prime number to output list, if not 1
        break 

    else:
        i += 1 # adding 1 to the index, repeats loop using next prime number

print(f"The Prime Factors of {orignalInputNumber} are {savedFactors}")
