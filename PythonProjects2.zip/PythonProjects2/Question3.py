import random
def randomNumbers():
    random1 = random.randint(0,10)
    random2 = random.randint(0,10)
    return [random1, random2]

def getAnswer(rNum1 , rNum2):
    userinput = int(input(f"\nWhat is {rNum1} x {rNum2}?\t"))
    return userinput

def checkAnswer(userAnswer, rNum1, rNum2):
    if(userAnswer == (rNum1 * rNum2)):
        return True
    else:
        return False
    
def startGame():
    playAgain = "y"
    points = 0

    print("\nWelcome to the multiplication game!")
    
    while(playAgain == "y"):
        rNumbers = randomNumbers()
        userInput = getAnswer(rNumbers[0], rNumbers[1])
        
        if(checkAnswer(userInput, rNumbers[0], rNumbers[1]) == True):
            points += 1
            print(f"Well done, you now have {points} points!")
        else:
            print(f"Unfortunatly thats incorrect, your points are {points}.")

        playAgain = input("Would you like to play again?(y/n): ")


startGame()